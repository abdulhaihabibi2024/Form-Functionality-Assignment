document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const name = document.getElementById('name').value;
    const lastname = document.getElementById('lastname').value;
    const username = document.getElementById('username').value;
    const gender = document.querySelector('input[name="gender"]:checked')?.value;
    const education = document.getElementById('education').value;

    const languages = [];
    document.querySelectorAll('input[name="language"]:checked').forEach(function(checkbox) {
        languages.push(checkbox.value);
    });

    document.getElementById('outputName').textContent = name;
    document.getElementById('outputLastname').textContent = lastname;
    document.getElementById('outputUsername').textContent = username;
    document.getElementById('outputGender').textContent = gender ? gender : 'Not specified';
    document.getElementById('outputEducation').textContent = education;
    document.getElementById('outputLanguages').textContent = languages.length > 0 ? languages.join(', ') : 'Not specified';
});
